import tkinter as tk
from tkinter import ttk, END, messagebox
import random
import pyperclip
import json
WIDTH=200
HEIGHT=200

window = tk.Tk()
window.title("Password Manager")
window.config(padx=50,pady=50,bg="#FFFFFF")


def search():
    website = entry_website.get()
    try:
        with open("data.json") as file:
            data = json.load(file)
    except FileNotFoundError:
        messagebox.showinfo(title="Error",message="no file data Found")
    else:
        if website in data:
            email = data[website]["email"]
            password = data[website]["password"]
            messagebox.showinfo(title=website,message=f"{email}\n{password}")
        else:
            messagebox.showinfo(title="Error",message=f"no details for this {website}")


# ---------------------------- PASSWORD GENERATOR ------------------------------- #
def work():
    letters = ['a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z']
    numbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9']
    symbols = ['!', '#', '$', '%', '&', '(', ')', '*', '+']

    nr_letters = random.randint(8, 10)
    nr_symbols = random.randint(2, 4)
    nr_numbers = random.randint(2, 4)

    password_list = []



    for char in range(nr_letters):
      password_list.append(random.choice(letters))

    for char in range(nr_symbols):
      password_list += random.choice(symbols)

    for char in range(nr_numbers):
      password_list += random.choice(numbers)

    random.shuffle(password_list)

    password = ""
    for char in password_list:
      password += char
    entry_password.delete(0,END)
    entry_password.insert(0,password)
    pyperclip.copy(password)

# ---------------------------- SAVE PASSWORD ------------------------------- #

def save():
    website = entry_website.get()
    email = entry_email.get()
    password = entry_password.get()
    new_data = {
        website: {
            "email":email,
            "password":password
        }
    }
    if len(website) == 0 or len(password)==0 or len(email) == 0:
        messagebox.showinfo()
    else:
        try:
            with open("data.json", "r") as data_file:
                # Reading old data
                data = json.load(data_file)
        except FileNotFoundError:
            with open("data.json", "w") as data_file:
                json.dump(new_data, data_file, indent=4)
        else:
            # Updating old data with new data
            data.update(new_data)

            with open("data.json", "w") as data_file:
                # Saving updated data
                json.dump(data, data_file, indent=4)
        finally:
            entry_website.delete(0, END)
            entry_password.delete(0, END)


# ---------------------------- UI SETUP ------------------------------- #

#Label <website>
website_label = ttk.Label(text="website")
website_label.grid(column=0,row=1)
website_label.focus()


#Label <email>
email_label = ttk.Label(text="email")
email_label.grid(column=0,row=2)

#Label <password>
password_label = ttk.Label(text="password")
password_label.grid(column=0,row=3)

#Logo
canvas = tk.Canvas(width=WIDTH,height=HEIGHT,bg="#FFFFFF")
logo_image = tk.PhotoImage(file="logo.png")
canvas.create_image(WIDTH//2,HEIGHT//2,image=logo_image)
canvas.grid(column=1,row=0)

#Entry <website>
entry_website = ttk.Entry(width=32)
entry_website.grid(column=1,row=1)

#Entry <email>
entry_email = ttk.Entry(width=45)
entry_email.grid(column=1,row=2,columnspan=2)
entry_email.insert(0,"_____@gmail.com")

#Entry <password>
entry_password = ttk.Entry(width=32)
entry_password.grid(column=1,row=3)

#Button <add>
button_add = ttk.Button(text="add",width=45,command=save)
button_add.grid(column=1,row=4,columnspan=2)


#Button <search_website>
button_search_website = ttk.Button(text="search",command=search)
button_search_website.grid(column=2,row=1)

#Button <gen..pas>
button_gen = ttk.Button(text="gen..pass",command=work)
button_gen.grid(column=2,row=3)

window.mainloop()